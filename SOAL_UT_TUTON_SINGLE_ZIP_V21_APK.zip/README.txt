SOAL UT TUTON V21 - ANDROID APK PROJECT

This archive is a complete Android Gradle project. It includes:
- V21 HTML app as the WebView home page
- Supplied SOAL UT TUTON launcher icon
- Android WebView file picker support for selecting local PDF/DOCX files
- GitHub Actions workflow reference

SINGLE-ZIP GitHub method:
1. Upload this archive to the ROOT of your GitHub repository with the exact name:
   SOAL_UT_TUTON_SINGLE_ZIP_V21_APK.zip
2. Create .github/workflows/build-apk.yml in the repository and paste the workflow YAML supplied with this project.
3. Run Actions > Build SOAL UT TUTON APK > Run workflow.
4. Download the SOAL-UT-TUTON-V21-APK artifact.

PDF.js and Mammoth are downloaded during the GitHub build and packaged inside the APK.
After a successful build, PDF and DOCX preview engines are local in the installed app and do not require internet to open documents.

The app's HTML is based on the supplied V21 fix. The APK has not been built or tested on a physical Android device in this environment.
