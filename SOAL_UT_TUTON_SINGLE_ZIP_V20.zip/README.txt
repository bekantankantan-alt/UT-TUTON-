SOAL UT TUTON V20 - Android APK project

Cara pakai:
1. Extract ZIP ini.
2. Upload seluruh isi folder ke satu repository GitHub (branch main).
3. Buka tab Actions, pilih Build SOAL UT TUTON APK, lalu Run workflow.
4. Setelah selesai, download artifact SOAL-UT-TUTON-APK.

PDF.js dan Mammoth diunduh saat proses build lalu disimpan di dalam APK. Sesudah APK terpasang, preview PDF/DOCX bekerja offline. File picker Android disediakan oleh WebChromeClient. Preview mendukung tombol zoom dan pinch-to-zoom.

Catatan: koneksi internet diperlukan saat GitHub Actions membangun APK untuk mengambil library dan dependency Gradle. Setelah APK terpasang, dokumen lokal dapat dipreview tanpa internet. DOCX didukung, DOC lama tidak.
