SOAL UT TUTON - ANDROID SOURCE ZIP

ZIP ini adalah satu paket sumber aplikasi. Tidak perlu mengambil atau mengunggah PNG ikon, MP3, cover DOCX, atau HTML secara terpisah. Semuanya sudah dipasang/ditanamkan ke proyek.

CARA PAKAI DENGAN GITHUB ACTIONS (TANPA EKSTRAK ZIP DI HP)
1. Buat repository GitHub baru.
2. Upload file SOAL_UT_TUTON_ANDROID.zip ini ke root repository sebagai satu file.
3. Buat file workflow baru di repository dengan path: .github/workflows/build.yml
4. Salin kode YAML yang diberikan bersama ZIP ini ke file tersebut, lalu commit.
5. Buka tab Actions, pilih Build SOAL UT TUTON APK, lalu Run workflow.
6. Setelah selesai, unduh artifact SOAL-UT-TUTON-APK. Di dalamnya ada app-debug.apk.

DETAIL
- Aplikasi WebView Android dengan HTML mandiri (background, gambar, audio MP3, dan cover DOCX sudah tertanam).
- Ikon aplikasi memakai PNG yang dikirim, dengan sudut luar transparan.
- Pemilih file Android mendukung PDF, DOC/DOCX, JPG, dan PNG.
- Unduhan cover dan file jawaban diarahkan ke folder Download Android.
- Minimum Android 10 (API 29).
- Musik mulai setelah tombol START ditekan karena pembatasan autoplay Android.
- Ikon pada launcher Android tertentu masih dapat mengikuti bentuk/masking yang ditetapkan sistem operasi/perangkat.
